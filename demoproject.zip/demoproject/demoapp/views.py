from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages, auth


# Create your views here.
def home(request):
    return render(request, 'demoapp/index.html')


def signup(request):
    if request.method == "POST":
        username = request.POST.get('username')
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        password = request.POST.get('password')

        myUser = User.objects.create_user(username, password)
        myUser.first_name = fname
        myUser.last_name = lname

        myUser.save()

        messages.success(request, "Account created successfully")

        return redirect('signin')
    return render(request, 'demoapp/signup.html')


def signin(request):
    if request.method == "POST":
        username = request.POST.get('username')
        pwd = request.POST.get('password')

        user = authenticate(username=username, password=pwd)
        print(user, "userdata")
        if user is not None:
            login(request, user)
            fname = user.first_name
            return render(request, 'demoapp/loginSuccess.html')
        else:
            messages.error(request, "wrong credentials")
            return redirect('home-page')

    return render(request, 'demoapp/signin.html')


def signout(request):
    pass
